require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const QRCode = require('qrcode');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const path = require('path');
const menuSeed = require('./data/menu-seed.json');

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (process.env.NODE_ENV === 'production' && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32 || !process.env.OWNER_EMAIL || !process.env.OWNER_PASSWORD)) {
  throw new Error('Production requires SESSION_SECRET (32+ characters), OWNER_EMAIL and OWNER_PASSWORD.');
}
const db = new Database(path.join(__dirname, 'woodside.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS menu_items (id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, description TEXT DEFAULT '', price INTEGER NOT NULL, available INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY, customer_name TEXT NOT NULL, phone TEXT NOT NULL, booking_date TEXT NOT NULL, booking_time TEXT NOT NULL, guests INTEGER NOT NULL, notes TEXT DEFAULT '', status TEXT DEFAULT 'Pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, order_code TEXT UNIQUE NOT NULL, table_number TEXT NOT NULL, customer_name TEXT DEFAULT '', phone TEXT DEFAULT '', items_json TEXT NOT NULL, total INTEGER NOT NULL, payment_method TEXT NOT NULL, payment_status TEXT DEFAULT 'Unpaid', status TEXT DEFAULT 'New', razorpay_order_id TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

// Import the verified, priced menu once on first launch. Unpriced and conflicting items are held back for owner confirmation.
if (db.prepare('SELECT COUNT(*) AS count FROM menu_items').get().count === 0) {
  const insertMenu = db.prepare('INSERT INTO menu_items(name,category,description,price) VALUES(?,?,?,?)');
  const seedMenu = db.transaction(items => { for (const item of items) insertMenu.run(item.name, item.category, item.description || '', item.price); });
  seedMenu(menuSeed);
}

if (process.env.OWNER_EMAIL && process.env.OWNER_PASSWORD) {
  const exists = db.prepare('SELECT id FROM admins WHERE email=?').get(process.env.OWNER_EMAIL.toLowerCase());
  if (!exists) db.prepare('INSERT INTO admins(email,password_hash) VALUES(?,?)').run(process.env.OWNER_EMAIL.toLowerCase(), bcrypt.hashSync(process.env.OWNER_PASSWORD, 12));
}

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '200kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: 'woodside.sid', secret: process.env.SESSION_SECRET || 'local-development-only-change-before-deploy-woodside',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const requireAdmin = (req, res, next) => req.session.admin ? next() : res.status(401).json({ error: 'Please log in again.' });
const clean = (v, max=180) => String(v ?? '').trim().slice(0, max);
const money = n => Number.isInteger(n) && n > 0 && n <= 100000;

app.get('/api/public', (req,res) => {
  const menu = db.prepare('SELECT id,name,category,description,price FROM menu_items WHERE available=1 ORDER BY id').all();
  res.json({ menu, instagram: 'https://www.instagram.com/thewoodsidecafe/', whatsapp: process.env.CAFE_WHATSAPP || '', phone: process.env.CAFE_PHONE || '+918368860288', address: process.env.CAFE_ADDRESS || '1st Floor, City Centre Market, Ramprastha Road, Ramprastha Colony, B Block, Chander Nagar, Ghaziabad', onlinePaymentsEnabled: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) });
});
app.get('/api/qr', async (req,res) => {
  try {
    const base = (process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');
    const data = await QRCode.toDataURL(`${base}/order`, { width: 600, margin: 2, color: { dark: '#203b30', light: '#ffffff' } });
    res.json({ data, url: `${base}/order` });
  } catch { res.status(500).json({error:'Could not create QR code.'}); }
});
app.post('/api/bookings', (req,res) => {
  const name=clean(req.body.name,100), phone=clean(req.body.phone,20), date=clean(req.body.date,10), time=clean(req.body.time,10), guests=Number(req.body.guests), notes=clean(req.body.notes,500);
  if (!name || !/^\+?[0-9\s]{8,16}$/.test(phone) || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time) || !Number.isInteger(guests) || guests<1 || guests>20) return res.status(400).json({error:'Please check your booking details.'});
  const result=db.prepare('INSERT INTO bookings(customer_name,phone,booking_date,booking_time,guests,notes) VALUES(?,?,?,?,?,?)').run(name,phone,date,time,guests,notes);
  res.json({ok:true,id:result.lastInsertRowid,message:'Your request has been sent. The cafe team will confirm it shortly.'});
});
app.post('/api/orders', async (req,res) => {
  const table=clean(req.body.tableNumber,12), name=clean(req.body.name,100), phone=clean(req.body.phone,20), method=clean(req.body.paymentMethod,20), cart=Array.isArray(req.body.items)?req.body.items:[];
  if (!table || !/^[a-zA-Z0-9 -]{1,12}$/.test(table) || !['counter','online'].includes(method) || cart.length<1 || cart.length>30) return res.status(400).json({error:'Please enter a valid table number and order.'});
  let items=[], total=0;
  for (const row of cart) {
    const id=Number(row.id), qty=Number(row.quantity);
    if (!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>20) return res.status(400).json({error:'Invalid cart item.'});
    const item=db.prepare('SELECT id,name,price FROM menu_items WHERE id=? AND available=1').get(id);
    if (!item) return res.status(400).json({error:'One of the selected items is unavailable.'});
    items.push({id:item.id,name:item.name,price:item.price,quantity:qty}); total += item.price*qty;
  }
  if (total>200000) return res.status(400).json({error:'Order total is too high.'});
  const code='WS'+Date.now().toString().slice(-8)+crypto.randomBytes(2).toString('hex').toUpperCase();
  if (method==='online') {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({error:'Online payment is not configured yet. Please choose Pay at counter.'});
    try {
      const gateway=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
      const rp=await gateway.orders.create({amount:total*100,currency:'INR',receipt:code});
      const result=db.prepare('INSERT INTO orders(order_code,table_number,customer_name,phone,items_json,total,payment_method,payment_status,razorpay_order_id) VALUES(?,?,?,?,?,?,?,?,?)').run(code,table,name,phone,JSON.stringify(items),total,'online','Pending',rp.id);
      return res.json({ok:true,orderId:result.lastInsertRowid,orderCode:code,razorpay:{key:process.env.RAZORPAY_KEY_ID,order_id:rp.id,amount:rp.amount,currency:rp.currency,name:'Woodside Cafe',description:`Order ${code}`,prefill:{name,contact:phone}}});
    } catch(e) { console.error('Razorpay order error',e.message); return res.status(502).json({error:'Could not start online payment. Please try counter payment.'}); }
  }
  const result=db.prepare('INSERT INTO orders(order_code,table_number,customer_name,phone,items_json,total,payment_method,payment_status) VALUES(?,?,?,?,?,?,?,?)').run(code,table,name,phone,JSON.stringify(items),total,'counter','Pay at counter');
  res.json({ok:true,orderId:result.lastInsertRowid,orderCode:code,message:'Order sent to the cafe team. Please pay at the counter.'});
});
app.post('/api/payments/verify', (req,res) => {
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
  if (!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({error:'Payment gateway is not configured.'});
  const order=db.prepare('SELECT id FROM orders WHERE razorpay_order_id=?').get(razorpay_order_id);
  if (!order) return res.status(404).json({error:'Order not found.'});
  const signature = String(razorpay_signature || '');
  if (!/^[a-f0-9]{64}$/i.test(signature)) return res.status(400).json({error:'Payment verification failed.'});
  const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  if (!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature))) return res.status(400).json({error:'Payment verification failed.'});
  db.prepare("UPDATE orders SET payment_status='Paid' WHERE id=?").run(order.id);
  res.json({ok:true});
});

app.post('/api/admin/login', loginLimiter, (req,res) => {
  const email=clean(req.body.email,180).toLowerCase(), password=String(req.body.password||'');
  const admin=db.prepare('SELECT * FROM admins WHERE email=?').get(email);
  if (!admin || !bcrypt.compareSync(password,admin.password_hash)) return res.status(401).json({error:'Email or password is incorrect.'});
  req.session.regenerate(err=>{ if(err) return res.status(500).json({error:'Could not start session.'}); req.session.admin={id:admin.id,email:admin.email}; res.json({ok:true,email:admin.email}); });
});
app.post('/api/admin/logout', requireAdmin, (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/me', (req,res)=>res.json({loggedIn:!!req.session.admin,email:req.session.admin?.email||''}));
app.get('/api/admin/data', requireAdmin, (req,res)=>{
  res.json({bookings:db.prepare('SELECT * FROM bookings ORDER BY created_at DESC').all(),orders:db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all(),menu:db.prepare('SELECT * FROM menu_items ORDER BY id').all()});
});
app.post('/api/admin/bookings/:id/status', requireAdmin, (req,res)=>{
  const status=clean(req.body.status,20); if(!['Confirmed','Cancelled'].includes(status)) return res.status(400).json({error:'Invalid status.'});
  const r=db.prepare('UPDATE bookings SET status=? WHERE id=?').run(status,Number(req.params.id)); res.json({ok:r.changes>0});
});
app.post('/api/admin/orders/:id/status', requireAdmin, (req,res)=>{
  const status=clean(req.body.status,20); if(!['Accepted','Preparing','Ready','Served','Cancelled'].includes(status)) return res.status(400).json({error:'Invalid status.'});
  const r=db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,Number(req.params.id)); res.json({ok:r.changes>0});
});
app.post('/api/admin/menu', requireAdmin, (req,res)=>{
  const name=clean(req.body.name,100),category=clean(req.body.category,50),description=clean(req.body.description,250),price=Number(req.body.price);
  if(!name||!category||!money(price)) return res.status(400).json({error:'Enter a name, category and valid price in rupees.'});
  const r=db.prepare('INSERT INTO menu_items(name,category,description,price) VALUES(?,?,?,?)').run(name,category,description,price); res.json({ok:true,id:r.lastInsertRowid});
});
app.delete('/api/admin/menu/:id', requireAdmin, (req,res)=>{const r=db.prepare('DELETE FROM menu_items WHERE id=?').run(Number(req.params.id));res.json({ok:r.changes>0});});
app.post('/api/admin/menu/:id/availability', requireAdmin, (req,res)=>{const r=db.prepare('UPDATE menu_items SET available=? WHERE id=?').run(req.body.available?1:0,Number(req.params.id));res.json({ok:r.changes>0});});
app.get('/admin', (req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('/order', (req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.get('*', (req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Woodside Cafe running on http://localhost:${PORT}`));
