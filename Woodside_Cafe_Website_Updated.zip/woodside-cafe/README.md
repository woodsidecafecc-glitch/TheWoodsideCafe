# THE WOODSIDE CAFÉ — website project

A responsive café website with:
- Public homepage and real café photographs supplied in the project files
- Full digital menu and dine-in ordering
- One universal QR code for every table; customers enter their own table number
- Table reservation requests
- Owner dashboard for reservations, orders and menu availability
- Pay-at-counter ordering
- Razorpay online-payment support (inactive until the café owner configures their own keys)
- Instagram, Google Maps listing/reviews link and click-to-call contact

## Menu import and confirmation notes

The first server start imports 104 priced menu entries from `data/menu-seed.json` into the SQLite database. It imports only when the database menu is empty, so restarting the server will not duplicate menu entries. The owner can then hide or add items in Owner Desk → Menu editor.

These entries are intentionally not published in the order menu until the café confirms them:
- Aloo Cheese Sandwich: the supplied menu pages show conflicting prices (₹159 and ₹179).
- Garlic Bread variants: their prices were not visible in the supplied menu screenshots.

The Breakfast Combo is listed at ₹249, but its exact contents were not legible enough to describe. Promotional claims in the dessert image (student discount, free dessert, extra discount) are not published pending confirmation.

## Contact and listings

- Instagram: `https://www.instagram.com/thewoodsidecafe/`
- Google listing: the website links directly to the supplied café's Google Maps place listing so visitors can read current reviews and directions. The site does not scrape or republish Google reviews. A live on-site Google review feed would require the owner's approved Google Places API setup and appropriate attribution.
- The menu prints `+91 83688 60288`; it is configured as the click-to-call number. WhatsApp remains hidden until the café confirms that this number is WhatsApp-enabled. Set `CAFE_WHATSAPP` only after confirmation.
- Café address is configured from the supplied Google business listing.

## Run locally

Requires Node.js 20 or newer.

1. Copy `.env.example` to `.env`.
2. Set a unique `SESSION_SECRET` (at least 32 characters), `OWNER_EMAIL`, and a strong `OWNER_PASSWORD`.
3. Keep `PUBLIC_URL=http://localhost:3000` for local testing.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.
7. Owner dashboard: `http://localhost:3000/admin`.
8. Dine-in ordering page: `http://localhost:3000/order`.

The first server start creates the owner login if that email does not already exist. Changing `.env` later does not overwrite an existing admin account.

## Universal QR

In the owner dashboard, choose **Universal QR** and download the QR image after setting `PUBLIC_URL` to the final HTTPS website address. Print the same QR for all tables. The QR opens `/order`; customers manually enter the table number at checkout.

## Before publishing

- Set `NODE_ENV=production`, a unique 32+ character `SESSION_SECRET`, owner login credentials, and the real HTTPS `PUBLIC_URL`.
- Deploy to a Node.js host with persistent storage, or migrate SQLite to a managed database before using ephemeral/serverless hosting.
- Configure a persistent session store and database backups; Express's default in-memory session store is only suitable for local testing.
- Confirm the phone/WhatsApp number, address, opening hours, menu prices, missing menu entries, reservation policy, privacy notice and refund/cancellation process with the café owner.
- Configure Razorpay keys in the café owner's own account and test successful, failed and cancelled payments before enabling online payment.
- Test the site on a phone and desktop, test QR scanning from a second device, and verify booking/order notifications and operational workflow with café staff.

## Main routes

- `/` — public website
- `/order` — universal dine-in ordering page
- `/admin` — owner desk
- `/api/qr` — generates the universal QR using `PUBLIC_URL`
